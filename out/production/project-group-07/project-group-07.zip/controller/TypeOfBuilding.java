package controller;

public class TypeOfBuilding {
    
}