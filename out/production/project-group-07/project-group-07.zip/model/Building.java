package model;

public class Building {
    
}