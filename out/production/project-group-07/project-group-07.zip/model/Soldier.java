package model;
import controller.TypeOfSoldier;
public class Soldier {
    TypeOfSoldier typeOfSoldier;
    public TypeOfSoldier getTypeOfSoldier() {
        return this.typeOfSoldier;
    }
    
}