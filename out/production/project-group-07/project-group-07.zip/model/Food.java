package model;

public enum Food {
    MEAT,
    BREAD,
    APPLE,
    CHEESE;
    private int amount;
    
}
