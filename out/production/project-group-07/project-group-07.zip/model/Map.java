package model;
import java.util.*; 

public class Map {
    private ArrayList<ArrayList<MapPixel>> field = new ArrayList<ArrayList<MapPixel>>();
    public Map() {

    }
    public String showMap(int x , int y){
        String output = "";
        
    }    
}