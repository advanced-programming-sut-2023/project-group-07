package model;
import java.util.*;
import controller.TypeOfPixel;
public class MapPixel {
    private TypeOfPixel typeOfPixel;
    private ArrayList <Soldier> soldiers = new ArrayList<Soldier>();
    private ArrayList <Building> buildings = new ArrayList<Building>();

}