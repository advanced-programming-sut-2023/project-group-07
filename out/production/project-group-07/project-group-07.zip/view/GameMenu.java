package view;
import java.util.Scanner;
import controller.GameMenuController;
public class GameMenu {
    GameMenuController gameMenuController = new GameMenuController();
    public void run(Scanner scanner) {
        while(true){

        }
    }
    private String getPopulation(){

    }
    private String getPopularity(){
        //System.out.println("Your popularity: "+.getPopularity()+);
    }
    private String setTaxRate(){

    }
    private String showTaxRate(){
        System.out.println("Your tax rate: "+government.getTaxAmount()+"coins\nPopularity effect: "+government.getTaxPopularity());
    }
    private void endOfTurn(){
        
    }
    private void showMap()
}