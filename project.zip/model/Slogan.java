package model;

public enum Slogan {
    ENTEZ("UNDER THE SAME FLAG, FOR A SINGLE ENTEZ");
    
    String string;
    private Slogan(String string) {
        this.string = string;
    }
}